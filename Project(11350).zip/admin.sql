create database hms 
use hms

create table admin1
(C_Room varchar (25),
R_Available int,
R_Charges money
)
select * from admin
insert into admin1(C_room,R_Available,R_Charges)
values('Luxury',25,5000)

create table customer
(Name nvarchar (30),
CNIC int,
Address nvarchar(30),
Room_Type nvarchar(30),
Res_Room int,
Duration nvarchar(30),
Pay nvarchar(30))


create table customer1
(Name varchar (30),
CNIC int,
Address varchar(30),
Room_Type varchar(30),
Res_Room int,
Duration varchar(30),
Pay varchar(30))
select * from customer
ALTER TABLE customer
   ALTER COLUMN Pay nvarchar(30)
   ALTER TABLE customer
   ALTER COLUMN Duration int

   insert into customer1 values ('ahmed',123,'nazimabad','luxury',3,'3days','cash')
   insert into admin1 values ('Luxury',12,58000.00)
   delete from admin1 where R_Available=26
   select * from admin1